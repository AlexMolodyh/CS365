Please remember to start he server before using the client. 

Please cd into the appropriate folders to use the different versions of the fortune tellers.

The server can be ran with -> java FortuneTellerServer
The client can be ran with -> java FortuneTellerClient

The GUI version of fortune teller is in JavaFX so you will need at leased java8 to run it.

When using the CMDFortuneTeller version: Enter q to quit and enter a date in the format of mm/dd/yyyy like 02/21/1990.