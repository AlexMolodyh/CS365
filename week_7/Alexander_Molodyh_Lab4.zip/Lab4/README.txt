Please execute with: java BridgeManager.

The no_starve folder contains the solution for a semaphore with no starvation.
The starve folder contains the semaphore with no deadlocks but potentially starvable process.