Please run Part_1 with: java Factory
Please run Part_2 with: java Factory
Please run Part_3 with: java Main